"""AFAQ smart planning, built on Sprint 4's content-based recommendations.

The schedule is a *proposal*: a 90-minute visit inside the listed event opening
hours, not an official booking or a claim about the event's session duration.
No Gemini, new database tables, or new recommendation algorithm are required.
"""

import re
from collections import Counter
from datetime import date, timedelta

from models.calendar_event import CalendarEvent
from models.event import Event
from services.recommendation_service import get_recommendations_for_user

MAX_DAYS = 7
MAX_HORIZON_DAYS = 90
VISIT_MINUTES = 90
BUFFER_MINUTES = 30
MAX_EVENTS_PER_DAY = 3

# Local, date-bound planning windows, measured in minutes since midnight.
TIME_WINDOWS = {
    "morning": (8 * 60, 12 * 60),
    "afternoon": (12 * 60, 17 * 60),
    "evening": (17 * 60, 24 * 60),
    "any": (8 * 60, 24 * 60),
}

# Examples in AFAQ's catalog: "16:00 - 23:59", "16:00 - 00:45".
_TIME_PATTERN = re.compile(
    r"^\s*(\d{1,2}):(\d{2})\s*([AaPp][Mm])?\s*"
    r"(?:-|–|—|to)\s*"
    r"(\d{1,2}):(\d{2})\s*([AaPp][Mm])?\s*$"
)
_SINGLE_TIME_PATTERN = re.compile(r"^\s*(\d{1,2}):(\d{2})\s*([AaPp][Mm])?\s*$")


def _minutes(hours, minutes, ampm=None):
    if minutes > 59 or hours > 24 or hours < 0:
        return None
    if ampm:
        if not 1 <= hours <= 12:
            return None
        hours = hours % 12 + (12 if ampm.upper() == "PM" else 0)
    elif hours == 24 and minutes != 0:
        return None
    return hours * 60 + minutes


def parse_event_hours(raw):
    """Return opening interval [start, end) in minutes, or None if unclear.

    End times before start times are treated as *next-day closing times*.
    For safety, proposals only occupy time on the user's selected date.
    """
    if not raw or not isinstance(raw, str):
        return None
    text = raw.strip()
    match = _TIME_PATTERN.fullmatch(text)
    if match:
        h1, m1, ap1, h2, m2, ap2 = match.groups()
        start = _minutes(int(h1), int(m1), ap1)
        end = _minutes(int(h2), int(m2), ap2)
        if start is None or end is None or start >= 24 * 60:
            return None
        if end <= start:
            end += 24 * 60
        return start, end
    single = _SINGLE_TIME_PATTERN.fullmatch(text)
    if single:
        h, m, ampm = single.groups()
        start = _minutes(int(h), int(m), ampm)
        return (start, start + VISIT_MINUTES) if start is not None and start < 24 * 60 else None
    return None


def _display_time(minutes):
    return f"{minutes // 60:02d}:{minutes % 60:02d}"


def _available_on(event, planned_date):
    return bool(
        event.is_active
        and event.start_date <= planned_date <= (event.end_date or event.start_date)
    )


def _find_visit_slot(event_hours, window, busy):
    start = max(event_hours[0], window[0])
    stop = min(event_hours[1], window[1], 24 * 60)
    # Allow a 90-minute suggested visit with 30 minutes between visits.
    for proposed in range(start, stop - VISIT_MINUTES + 1, 15):
        end = proposed + VISIT_MINUTES
        if all(
            end + BUFFER_MINUTES <= taken_start
            or proposed >= taken_end + BUFFER_MINUTES
            for taken_start, taken_end in busy
        ):
            return proposed, end
    return None


def validate_planning_request(raw_dates, time_window, count, today=None):
    """Validate the selected dates and preferences; return dates and count."""
    today = today or date.today()
    if time_window not in TIME_WINDOWS:
        raise ValueError("Please choose a valid preferred time.")
    try:
        count = int(count)
    except (TypeError, ValueError):
        raise ValueError("Please choose between 1 and 3 events per day.") from None
    if not 1 <= count <= MAX_EVENTS_PER_DAY:
        raise ValueError("Please choose between 1 and 3 events per day.")

    if not raw_dates or len(raw_dates) > MAX_DAYS:
        raise ValueError("Choose between 1 and 7 dates.")
    selected = []
    for raw in raw_dates:
        try:
            day = date.fromisoformat(raw)
        except (TypeError, ValueError):
            raise ValueError("Please select valid dates.") from None
        if not today <= day <= today + timedelta(days=MAX_HORIZON_DAYS):
            raise ValueError("Choose dates within the next 90 days.")
        if day in selected:
            raise ValueError("Please do not select the same day twice.")
        selected.append(day)
    return sorted(selected), count


def generate_smart_schedule(user_id, selected_days, preferred_time="any", max_per_day=2):
    """Propose a schedule without changing the database or personal calendar.

    Entries already on the user's calendar count toward the daily cap, and
    already-saved event IDs are not suggested again (unique user/event key).
    """
    if not user_id:
        return []
    selected_days, max_per_day = validate_planning_request(
        [day.isoformat() for day in selected_days], preferred_time, max_per_day
    )
    active_events = Event.query.filter(Event.is_active == True).all()
    if not active_events:
        return [{"date": day, "items": [], "existing_count": 0} for day in selected_days]

    existing_entries = CalendarEvent.query.filter_by(user_id=user_id).all()
    existing_ids = {entry.event_id for entry in existing_entries}
    saved_on = Counter(entry.scheduled_date for entry in existing_entries)

    # Sprint 4's ranking is the relevance signal. Request the full catalog,
    # because the first six matches might not run on the selected dates.
    ranked = get_recommendations_for_user(user_id, limit=len(active_events))
    active_by_id = {event.id: event for event in active_events}
    eligible = [active_by_id[event.id] for event in ranked
                if event.id in active_by_id and event.id not in existing_ids]

    used_ids = set()
    generated = []
    for day in selected_days:
        busy = []
        items = []
        remaining = max(0, max_per_day - saved_on.get(day, 0))
        for event in eligible:
            if len(items) >= remaining:
                break
            if event.id in used_ids or not _available_on(event, day):
                continue
            hours = parse_event_hours(event.time)
            if hours is None:
                continue  # Do not invent hours for an event with missing/unclear times.
            slot = _find_visit_slot(hours, TIME_WINDOWS[preferred_time], busy)
            if slot is None:
                continue
            start, end = slot
            items.append({
                "event": event,
                "event_id": event.id,
                "date": day,
                "suggested_start": _display_time(start),
                "suggested_end": _display_time(end),
                "listed_hours": event.time,
            })
            busy.append(slot)
            used_ids.add(event.id)
        generated.append({
            "date": day,
            "items": items,
            "existing_count": saved_on.get(day, 0),
        })
    return generated
