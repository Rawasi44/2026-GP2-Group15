"""
Sprint 4 — Content-Based Recommendation System.

Flow (matches the GP2 report methodology):

    User Interactions (Favorites, Calendar, Ratings, Search History)
        -> Weighted User Profile
    Event Content (title + category + description)
        -> TF-IDF vectors
    User Profile Vector  vs.  Active Event Vectors
        -> Cosine Similarity
        -> Ranking
        -> Top personalized recommendations

Only Event.is_active == True events are ever returned as a recommendation
candidate. Interaction history pointing at an inactive (soft-deleted) event
is still allowed to shape the user's profile -- it is a real historical
signal of what the user likes -- it just never comes back out as a result.

This module is read-only: it never creates, updates, or deletes any
Favorite / CalendarEvent / Rating / Search / Event row. It only queries.

Recently Viewed is intentionally NOT used as an interaction source here --
that feature was permanently discontinued for personalization purposes.
"""

from sqlalchemy import func, desc

from extensions import db
from models.event import Event
from models.favorite import Favorite
from models.calendar_event import CalendarEvent
from models.rating import Rating
from models.search import Search

try:
    from sklearn.feature_extraction.text import TfidfVectorizer
    from sklearn.metrics.pairwise import cosine_similarity
except ImportError:  # pragma: no cover - guards a missing/broken install
    TfidfVectorizer = None
    cosine_similarity = None


# ---------------------------------------------------------------------------
# Centralized interaction weights.
#
# These are the ONLY numbers that should ever need tuning. Everything else
# in this file just reads from this dict.
#
# Rating weights follow the GP2 requirement:
#   5 stars -> 5, 4 stars -> 4, 3 stars -> 2, 1-2 stars -> does not
#   positively strengthen that event's influence on the profile (weight 0,
#   effectively ignored).
# ---------------------------------------------------------------------------
INTERACTION_WEIGHTS = {
    "calendar": 4,
    "favorite": 3,
    "rating_5": 5,
    "rating_4": 4,
    "rating_3": 2,
    "rating_low": 0,   # 1-2 star ratings: excluded from the positive profile
    "search": 1,
}

RECOMMENDATION_LIMIT = 6


# ---------------------------------------------------------------------------
# Event content representation
# ---------------------------------------------------------------------------
def _event_text(event):
    """
    Builds the textual representation of an event used for TF-IDF:
    title + category + description. Missing/blank fields are skipped
    safely rather than crashing or injecting the literal string "None".
    """
    parts = [event.title, event.category, event.description]
    parts = [p.strip() for p in parts if p and isinstance(p, str) and p.strip()]
    return " ".join(parts)


def _all_events():
    """All events, active and inactive. Used to build the TF-IDF vocabulary
    so that historical interactions with a now-inactive event can still be
    represented, even though inactive events are never recommended."""
    return Event.query.all()


def _active_events():
    """Only events eligible to be recommended."""
    return Event.query.filter(Event.is_active == True).all()


def _build_vectorizer_and_matrix(events):
    """
    Fits a single TF-IDF vectorizer over the text of `events` and returns
    (vectorizer, matrix). Returns (None, None) if there is nothing usable
    to vectorize (empty event list, or every event's text is empty/only
    stopwords) so callers can fall back safely instead of crashing.
    """
    if not events or TfidfVectorizer is None:
        return None, None

    texts = [_event_text(e) for e in events]
    if not any(text.strip() for text in texts):
        return None, None

    vectorizer = TfidfVectorizer(stop_words="english")
    try:
        matrix = vectorizer.fit_transform(texts)
    except ValueError:
        # e.g. every document was empty after stopword removal
        return None, None

    return vectorizer, matrix


# ---------------------------------------------------------------------------
# Gathering this user's own interaction data (never another user's)
# ---------------------------------------------------------------------------
def _gather_event_interaction_weights(user_id):
    """
    Returns {event_id: combined_weight} built from this user's Favorites,
    Calendar entries, and Ratings.

    If the same event shows up in more than one source (e.g. favorited AND
    rated 5 stars), its weights are simply summed -- a straightforward and
    easy-to-explain way to combine multiple positive signals about the same
    event, without double counting favorites as two separate favorites.
    """
    weights = {}

    for fav in Favorite.query.filter_by(user_id=user_id).all():
        weights[fav.event_id] = weights.get(fav.event_id, 0) + INTERACTION_WEIGHTS["favorite"]

    for entry in CalendarEvent.query.filter_by(user_id=user_id).all():
        weights[entry.event_id] = weights.get(entry.event_id, 0) + INTERACTION_WEIGHTS["calendar"]

    rating_weight_by_value = {
        5: INTERACTION_WEIGHTS["rating_5"],
        4: INTERACTION_WEIGHTS["rating_4"],
        3: INTERACTION_WEIGHTS["rating_3"],
    }
    for rating in Rating.query.filter_by(user_id=user_id).all():
        w = rating_weight_by_value.get(rating.value, INTERACTION_WEIGHTS["rating_low"])
        if w > 0:
            weights[rating.event_id] = weights.get(rating.event_id, 0) + w

    return weights


def _gather_search_keywords(user_id):
    """Returns this user's search keywords (most recent activity, oldest to
    newest is irrelevant here -- they are combined into one profile signal)."""
    rows = Search.query.filter_by(user_id=user_id).all()
    return [row.keyword for row in rows if row.keyword and row.keyword.strip()]


# ---------------------------------------------------------------------------
# Cold-start fallback
# ---------------------------------------------------------------------------
def _fallback_recommendations(active_events, limit, exclude_ids=None):
    """
    Used when a user has no usable interaction history (new user / cold
    start), or when the TF-IDF step can't run at all (e.g. an essentially
    empty catalog). Falls back to active Top Rated events, topped up with
    other active events so the section is never unexplainably empty.
    """
    exclude_ids = exclude_ids or set()

    top_rated_rows = (
        db.session.query(Event, func.avg(Rating.value).label("avg_rating"), func.count(Rating.id).label("cnt"))
        .join(Rating, Rating.event_id == Event.id)
        .filter(Event.is_active == True)
        .group_by(Event.id)
        .order_by(desc("avg_rating"), desc("cnt"))
        .all()
    )
    ordered = [row[0] for row in top_rated_rows]

    ordered_ids = {e.id for e in ordered}
    ordered += [e for e in active_events if e.id not in ordered_ids]

    result = []
    seen_ids = set()
    for event in ordered:
        if event.id in seen_ids:
            continue
        if event.id in exclude_ids:
            continue
        result.append(event)
        seen_ids.add(event.id)
        if len(result) >= limit:
            return result

    # Still short (e.g. every active event was excluded) -- top up ignoring
    # the exclusion so the section isn't left unnecessarily empty.
    for event in ordered:
        if event.id in seen_ids:
            continue
        result.append(event)
        seen_ids.add(event.id)
        if len(result) >= limit:
            break

    return result


# ---------------------------------------------------------------------------
# Main entry point
# ---------------------------------------------------------------------------
def get_recommendations_for_user(user_id, limit=RECOMMENDATION_LIMIT):
    """
    Returns up to `limit` active Event objects personalized for this user.

    Never raises on an empty catalog, a brand-new user, missing event
    descriptions, or a user with just one interaction -- each of those
    degrades gracefully to a smaller list or the cold-start fallback rather
    than crashing the Home page.
    """
    if not user_id:
        return []

    active_events = _active_events()
    if not active_events:
        return []

    event_weights = _gather_event_interaction_weights(user_id)
    search_keywords = _gather_search_keywords(user_id)
    has_signal = bool(event_weights) or bool(search_keywords)

    fav_and_calendar_ids = {
        row.event_id for row in Favorite.query.filter_by(user_id=user_id).all()
    } | {
        row.event_id for row in CalendarEvent.query.filter_by(user_id=user_id).all()
    }

    if not has_signal:
        # Cold start: no Favorites, Calendar entries, Ratings, or Search
        # History for this user yet.
        return _fallback_recommendations(active_events, limit)

    all_events = _all_events()
    vectorizer, matrix = _build_vectorizer_and_matrix(all_events)

    if vectorizer is None:
        # TF-IDF couldn't be built at all (e.g. every event has blank
        # title/category/description) -- fall back rather than crash.
        return _fallback_recommendations(active_events, limit, exclude_ids=fav_and_calendar_ids)

    id_to_index = {event.id: idx for idx, event in enumerate(all_events)}

    user_vector = None
    for event_id, weight in event_weights.items():
        idx = id_to_index.get(event_id)
        if idx is None:
            continue
        weighted_row = matrix[idx] * weight
        user_vector = weighted_row if user_vector is None else user_vector + weighted_row

    if search_keywords and INTERACTION_WEIGHTS["search"] > 0:
        search_text = " ".join(search_keywords)
        try:
            search_vector = vectorizer.transform([search_text]) * INTERACTION_WEIGHTS["search"]
            user_vector = search_vector if user_vector is None else user_vector + search_vector
        except ValueError:
            pass  # search text turned out to be empty/only stopwords

    if user_vector is None:
        # Every interacted event fell outside the vocabulary for some
        # reason, and there was no usable search text either.
        return _fallback_recommendations(active_events, limit, exclude_ids=fav_and_calendar_ids)

    active_indices = [id_to_index[event.id] for event in active_events]
    active_matrix = matrix[active_indices]

    similarities = cosine_similarity(user_vector, active_matrix)[0]
    scored = list(zip(active_events, similarities))
    scored.sort(key=lambda pair: pair[1], reverse=True)

    # Prefer events the user hasn't already saved to Favorites/Calendar,
    # so "Recommended For You" surfaces new things rather than events
    # they've already acted on -- but only when enough other relevant
    # events exist. Otherwise we top up with the next-best matches
    # (including already-saved ones) rather than showing an
    # under-filled section.
    ordered_events = [event for event, _score in scored]

    result = []
    seen_ids = set()
    for event in ordered_events:
        if event.id in fav_and_calendar_ids:
            continue
        result.append(event)
        seen_ids.add(event.id)
        if len(result) >= limit:
            return result

    if len(result) < limit:
        for event in ordered_events:
            if event.id in seen_ids:
                continue
            result.append(event)
            seen_ids.add(event.id)
            if len(result) >= limit:
                break

    if len(result) < limit:
        # Extremely sparse catalog -- top up with the cold-start fallback
        # so the section still shows something reasonable.
        for event in _fallback_recommendations(active_events, limit):
            if event.id in seen_ids:
                continue
            result.append(event)
            seen_ids.add(event.id)
            if len(result) >= limit:
                break

    return result[:limit]
