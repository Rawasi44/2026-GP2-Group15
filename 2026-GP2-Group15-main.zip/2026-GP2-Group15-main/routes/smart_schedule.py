"""Smart-planner pages; scheduling suggestions are saved only on confirmation."""

from datetime import date, timedelta

from flask import Blueprint, flash, redirect, render_template, request, session, url_for
from flask_login import current_user, login_required

from extensions import db
from models.calendar_event import CalendarEvent
from models.event import Event
from services.scheduling_service import (
    MAX_DAYS, MAX_HORIZON_DAYS, TIME_WINDOWS,
    generate_smart_schedule, validate_planning_request,
)

smart_schedule_bp = Blueprint("smart_schedule", __name__)


@smart_schedule_bp.route("/smart-schedule", methods=["GET", "POST"])
@login_required
def planner_page():
    schedule = None
    selected = []
    preferred = "any"
    count = 2
    today = date.today()

    if request.method == "POST":
        selected = request.form.getlist("dates")
        preferred = request.form.get("preferred_time", "any")
        count = request.form.get("max_per_day", "2")
        try:
            days, count = validate_planning_request(selected, preferred, count, today=today)
            schedule = generate_smart_schedule(
                current_user.user_id, days, preferred_time=preferred, max_per_day=count
            )
        except ValueError as exc:
            session.pop("afaq_proposed_schedule", None)
            flash(str(exc), "warning")
        else:
            proposed = [
                {"event_id": item["event_id"], "date": item["date"].isoformat()}
                for day in schedule for item in day["items"]
            ]
            # Flask's signed session: no hidden client-supplied event/date pairs
            # are accepted by the save endpoint.
            session["afaq_proposed_schedule"] = {
                "user_id": current_user.user_id,
                "items": proposed,
            }
            if not proposed:
                flash("No matching events with usable time information for these dates. Try other dates or 'Any time'.", "warning")
    return render_template(
        "smart_schedule.html",
        schedule=schedule,
        selected_dates=selected,
        preferred_time=preferred,
        max_per_day=count,
        time_windows=TIME_WINDOWS,
        today=today,
        last_day=today + timedelta(days=MAX_HORIZON_DAYS),
        max_days=MAX_DAYS,
    )


@smart_schedule_bp.route("/smart-schedule/save", methods=["POST"])
@login_required
def save_schedule():
    proposed = session.pop("afaq_proposed_schedule", None)
    if not proposed or proposed.get("user_id") != current_user.user_id:
        flash("Generate a schedule before saving it.", "warning")
        return redirect(url_for("smart_schedule.planner_page"))

    existing_ids = {
        entry.event_id
        for entry in CalendarEvent.query.filter_by(user_id=current_user.user_id).all()
    }
    today = date.today()
    to_save = []
    for item in proposed.get("items", []):
        try:
            event_id = int(item["event_id"])
            planned_day = date.fromisoformat(item["date"])
        except (KeyError, TypeError, ValueError):
            continue
        if event_id in existing_ids or not today <= planned_day <= today + timedelta(days=MAX_HORIZON_DAYS):
            continue
        event = db.session.get(Event, event_id)
        if not event or not event.is_active:
            continue
        if not event.start_date <= planned_day <= (event.end_date or event.start_date):
            continue
        # Schedule is deliberately not a reservation: no official booking made.
        to_save.append(CalendarEvent(
            user_id=current_user.user_id,
            event_id=event_id,
            scheduled_date=planned_day,
        ))
        existing_ids.add(event_id)

    if to_save:
        db.session.add_all(to_save)
        db.session.commit()
        flash(f"Saved {len(to_save)} event(s) to your Personal Calendar.", "success")
    else:
        flash("No new eligible events remained to save.", "warning")
    return redirect(url_for("smart_schedule.planner_page"))
